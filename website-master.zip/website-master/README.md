# https://malakes-odigoi.com/

[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](http://makeapullrequest.com)
[![code style: prettier](https://img.shields.io/badge/code_style-prettier-ff69b4.svg)](https://github.com/prettier/prettier)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

[![Netlify Status](https://api.netlify.com/api/v1/badges/10c5aa53-2c7d-401b-8e70-f4b1e2309ed8/deploy-status)](https://app.netlify.com/sites/frosty-villani-1730b5/deploys)

Ένα site με φωτογραφίες από μαλάκες οδηγούς αυτοκινήτων και μηχανών.
